package org.ldv.savonapi.model.entity

import com.fasterxml.jackson.annotation.JsonIgnore
import jakarta.persistence.CascadeType
import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import jakarta.persistence.OneToMany
import java.time.LocalDateTime

@Entity
class Utilisateur(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    open var id: Long? = null,
    @Column(unique = true)
    open var username: String,
    @Column(unique = true)
    open var email: String,
    @JsonIgnore
    open var password: String,
    var estBanned: Boolean = false,
    var estActif: Boolean = false,
    @ManyToOne
    @JoinColumn(name = "role_id")
    open var role: Role,
    @OneToMany(mappedBy = "utilisateur", cascade = [CascadeType.REMOVE], orphanRemoval = true)
    open var recettes: MutableList<Recette> = mutableListOf(),

) {
    var dateCreation: LocalDateTime = LocalDateTime.now()


}
